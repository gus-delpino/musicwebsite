/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	
	__webpack_require__(2);
	// require('./assets/js/jplayer.home.js');
	__webpack_require__(3);
	__webpack_require__(4);
	__webpack_require__(5);
	__webpack_require__(6);
	__webpack_require__(7);
	__webpack_require__(8);

	__webpack_require__(9);


/***/ },
/* 1 */,
/* 2 */
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_LOCAL_MODULE_0__;var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_LOCAL_MODULE_1__;var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;/*!
	 * imagesLoaded PACKAGED v3.1.8
	 * JavaScript is all like "You images are done yet or what?"
	 * MIT License
	 */

	(function(){function e(){}function t(e,t){for(var n=e.length;n--;)if(e[n].listener===t)return n;return-1}function n(e){return function(){return this[e].apply(this,arguments)}}var i=e.prototype,r=this,o=r.EventEmitter;i.getListeners=function(e){var t,n,i=this._getEvents();if("object"==typeof e){t={};for(n in i)i.hasOwnProperty(n)&&e.test(n)&&(t[n]=i[n])}else t=i[e]||(i[e]=[]);return t},i.flattenListeners=function(e){var t,n=[];for(t=0;e.length>t;t+=1)n.push(e[t].listener);return n},i.getListenersAsObject=function(e){var t,n=this.getListeners(e);return n instanceof Array&&(t={},t[e]=n),t||n},i.addListener=function(e,n){var i,r=this.getListenersAsObject(e),o="object"==typeof n;for(i in r)r.hasOwnProperty(i)&&-1===t(r[i],n)&&r[i].push(o?n:{listener:n,once:!1});return this},i.on=n("addListener"),i.addOnceListener=function(e,t){return this.addListener(e,{listener:t,once:!0})},i.once=n("addOnceListener"),i.defineEvent=function(e){return this.getListeners(e),this},i.defineEvents=function(e){for(var t=0;e.length>t;t+=1)this.defineEvent(e[t]);return this},i.removeListener=function(e,n){var i,r,o=this.getListenersAsObject(e);for(r in o)o.hasOwnProperty(r)&&(i=t(o[r],n),-1!==i&&o[r].splice(i,1));return this},i.off=n("removeListener"),i.addListeners=function(e,t){return this.manipulateListeners(!1,e,t)},i.removeListeners=function(e,t){return this.manipulateListeners(!0,e,t)},i.manipulateListeners=function(e,t,n){var i,r,o=e?this.removeListener:this.addListener,s=e?this.removeListeners:this.addListeners;if("object"!=typeof t||t instanceof RegExp)for(i=n.length;i--;)o.call(this,t,n[i]);else for(i in t)t.hasOwnProperty(i)&&(r=t[i])&&("function"==typeof r?o.call(this,i,r):s.call(this,i,r));return this},i.removeEvent=function(e){var t,n=typeof e,i=this._getEvents();if("string"===n)delete i[e];else if("object"===n)for(t in i)i.hasOwnProperty(t)&&e.test(t)&&delete i[t];else delete this._events;return this},i.removeAllListeners=n("removeEvent"),i.emitEvent=function(e,t){var n,i,r,o,s=this.getListenersAsObject(e);for(r in s)if(s.hasOwnProperty(r))for(i=s[r].length;i--;)n=s[r][i],n.once===!0&&this.removeListener(e,n.listener),o=n.listener.apply(this,t||[]),o===this._getOnceReturnValue()&&this.removeListener(e,n.listener);return this},i.trigger=n("emitEvent"),i.emit=function(e){var t=Array.prototype.slice.call(arguments,1);return this.emitEvent(e,t)},i.setOnceReturnValue=function(e){return this._onceReturnValue=e,this},i._getOnceReturnValue=function(){return this.hasOwnProperty("_onceReturnValue")?this._onceReturnValue:!0},i._getEvents=function(){return this._events||(this._events={})},e.noConflict=function(){return r.EventEmitter=o,e}, true?!(__WEBPACK_AMD_DEFINE_ARRAY__ = [], __WEBPACK_LOCAL_MODULE_0__ = (function(){return e}.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__))):"object"==typeof module&&module.exports?module.exports=e:this.EventEmitter=e}).call(this),function(e){function t(t){var n=e.event;return n.target=n.target||n.srcElement||t,n}var n=document.documentElement,i=function(){};n.addEventListener?i=function(e,t,n){e.addEventListener(t,n,!1)}:n.attachEvent&&(i=function(e,n,i){e[n+i]=i.handleEvent?function(){var n=t(e);i.handleEvent.call(i,n)}:function(){var n=t(e);i.call(e,n)},e.attachEvent("on"+n,e[n+i])});var r=function(){};n.removeEventListener?r=function(e,t,n){e.removeEventListener(t,n,!1)}:n.detachEvent&&(r=function(e,t,n){e.detachEvent("on"+t,e[t+n]);try{delete e[t+n]}catch(i){e[t+n]=void 0}});var o={bind:i,unbind:r}; true?!(__WEBPACK_AMD_DEFINE_FACTORY__ = (o), __WEBPACK_LOCAL_MODULE_1__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ? (__WEBPACK_AMD_DEFINE_FACTORY__.call(exports, __webpack_require__, exports, module)) : __WEBPACK_AMD_DEFINE_FACTORY__)):e.eventie=o}(this),function(e,t){ true?!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__WEBPACK_LOCAL_MODULE_0__,__WEBPACK_LOCAL_MODULE_1__], __WEBPACK_AMD_DEFINE_RESULT__ = function(n,i){return t(e,n,i)}.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__)):"object"==typeof exports?module.exports=t(e,require("wolfy87-eventemitter"),require("eventie")):e.imagesLoaded=t(e,e.EventEmitter,e.eventie)}(window,function(e,t,n){function i(e,t){for(var n in t)e[n]=t[n];return e}function r(e){return"[object Array]"===d.call(e)}function o(e){var t=[];if(r(e))t=e;else if("number"==typeof e.length)for(var n=0,i=e.length;i>n;n++)t.push(e[n]);else t.push(e);return t}function s(e,t,n){if(!(this instanceof s))return new s(e,t);"string"==typeof e&&(e=document.querySelectorAll(e)),this.elements=o(e),this.options=i({},this.options),"function"==typeof t?n=t:i(this.options,t),n&&this.on("always",n),this.getImages(),a&&(this.jqDeferred=new a.Deferred);var r=this;setTimeout(function(){r.check()})}function f(e){this.img=e}function c(e){this.src=e,v[e]=this}var a=e.jQuery,u=e.console,h=u!==void 0,d=Object.prototype.toString;s.prototype=new t,s.prototype.options={},s.prototype.getImages=function(){this.images=[];for(var e=0,t=this.elements.length;t>e;e++){var n=this.elements[e];"IMG"===n.nodeName&&this.addImage(n);var i=n.nodeType;if(i&&(1===i||9===i||11===i))for(var r=n.querySelectorAll("img"),o=0,s=r.length;s>o;o++){var f=r[o];this.addImage(f)}}},s.prototype.addImage=function(e){var t=new f(e);this.images.push(t)},s.prototype.check=function(){function e(e,r){return t.options.debug&&h&&u.log("confirm",e,r),t.progress(e),n++,n===i&&t.complete(),!0}var t=this,n=0,i=this.images.length;if(this.hasAnyBroken=!1,!i)return this.complete(),void 0;for(var r=0;i>r;r++){var o=this.images[r];o.on("confirm",e),o.check()}},s.prototype.progress=function(e){this.hasAnyBroken=this.hasAnyBroken||!e.isLoaded;var t=this;setTimeout(function(){t.emit("progress",t,e),t.jqDeferred&&t.jqDeferred.notify&&t.jqDeferred.notify(t,e)})},s.prototype.complete=function(){var e=this.hasAnyBroken?"fail":"done";this.isComplete=!0;var t=this;setTimeout(function(){if(t.emit(e,t),t.emit("always",t),t.jqDeferred){var n=t.hasAnyBroken?"reject":"resolve";t.jqDeferred[n](t)}})},a&&(a.fn.imagesLoaded=function(e,t){var n=new s(this,e,t);return n.jqDeferred.promise(a(this))}),f.prototype=new t,f.prototype.check=function(){var e=v[this.img.src]||new c(this.img.src);if(e.isConfirmed)return this.confirm(e.isLoaded,"cached was confirmed"),void 0;if(this.img.complete&&void 0!==this.img.naturalWidth)return this.confirm(0!==this.img.naturalWidth,"naturalWidth"),void 0;var t=this;e.on("confirm",function(e,n){return t.confirm(e.isLoaded,n),!0}),e.check()},f.prototype.confirm=function(e,t){this.isLoaded=e,this.emit("confirm",this,t)};var v={};return c.prototype=new t,c.prototype.check=function(){if(!this.isChecked){var e=new Image;n.bind(e,"load",this),n.bind(e,"error",this),e.src=this.src,this.isChecked=!0}},c.prototype.handleEvent=function(e){var t="on"+e.type;this[t]&&this[t](e)},c.prototype.onload=function(e){this.confirm(!0,"onload"),this.unbindProxyEvents(e)},c.prototype.onerror=function(e){this.confirm(!1,"onerror"),this.unbindProxyEvents(e)},c.prototype.confirm=function(e,t){this.isConfirmed=!0,this.isLoaded=e,this.emit("confirm",this,t)},c.prototype.unbindProxyEvents=function(e){n.unbind(e.target,"load",this),n.unbind(e.target,"error",this)},s});

/***/ },
/* 3 */
/***/ function(module, exports) {

	/**
	 * Cookie plugin
	 *
	 * Copyright (c) 2006 Klaus Hartl (stilbuero.de)
	 * Dual licensed under the MIT and GPL licenses:
	 * http://www.opensource.org/licenses/mit-license.php
	 * http://www.gnu.org/licenses/gpl.html
	 *
	 */

	/**
	 * Create a cookie with the given name and value and other optional parameters.
	 *
	 * @example $.cookie('the_cookie', 'the_value');
	 * @desc Set the value of a cookie.
	 * @example $.cookie('the_cookie', 'the_value', { expires: 7, path: '/', domain: 'jquery.com', secure: true });
	 * @desc Create a cookie with all available options.
	 * @example $.cookie('the_cookie', 'the_value');
	 * @desc Create a session cookie.
	 * @example $.cookie('the_cookie', null);
	 * @desc Delete a cookie by passing null as value. Keep in mind that you have to use the same path and domain
	 *       used when the cookie was set.
	 *
	 * @param String name The name of the cookie.
	 * @param String value The value of the cookie.
	 * @param Object options An object literal containing key/value pairs to provide optional cookie attributes.
	 * @option Number|Date expires Either an integer specifying the expiration date from now on in days or a Date object.
	 *                             If a negative value is specified (e.g. a date in the past), the cookie will be deleted.
	 *                             If set to null or omitted, the cookie will be a session cookie and will not be retained
	 *                             when the the browser exits.
	 * @option String path The value of the path atribute of the cookie (default: path of page that created the cookie).
	 * @option String domain The value of the domain attribute of the cookie (default: domain of page that created the cookie).
	 * @option Boolean secure If true, the secure attribute of the cookie will be set and the cookie transmission will
	 *                        require a secure protocol (like HTTPS).
	 * @type undefined
	 *
	 * @name $.cookie
	 * @cat Plugins/Cookie
	 * @author Klaus Hartl/klaus.hartl@stilbuero.de
	 */

	/**
	 * Get the value of a cookie with the given name.
	 *
	 * @example $.cookie('the_cookie');
	 * @desc Get the value of a cookie.
	 *
	 * @param String name The name of the cookie.
	 * @return The value of the cookie.
	 * @type String
	 *
	 * @name $.cookie
	 * @cat Plugins/Cookie
	 * @author Klaus Hartl/klaus.hartl@stilbuero.de
	 */
	jQuery.cookie = function(name, value, options) {
	    if (typeof value != 'undefined') { // name and value given, set cookie
	        options = options || {};
	        if (value === null) {
	            value = '';
	            options.expires = -1;
	        }
	        var expires = '';
	        if (options.expires && (typeof options.expires == 'number' || options.expires.toUTCString)) {
	            var date;
	            if (typeof options.expires == 'number') {
	                date = new Date();
	                date.setTime(date.getTime() + (options.expires * 24 * 60 * 60 * 1000));
	            } else {
	                date = options.expires;
	            }
	            expires = '; expires=' + date.toUTCString(); // use expires attribute, max-age is not supported by IE
	        }
	        // CAUTION: Needed to parenthesize options.path and options.domain
	        // in the following expressions, otherwise they evaluate to undefined
	        // in the packed version for some reason...
	        var path = options.path ? '; path=' + (options.path) : '';
	        var domain = options.domain ? '; domain=' + (options.domain) : '';
	        var secure = options.secure ? '; secure' : '';
	        document.cookie = [name, '=', encodeURIComponent(value), expires, path, domain, secure].join('');
	    } else { // only name given, get cookie
	        var cookieValue = null;
	        if (document.cookie && document.cookie != '') {
	            var cookies = document.cookie.split(';');
	            for (var i = 0; i < cookies.length; i++) {
	                var cookie = jQuery.trim(cookies[i]);
	                // Does this cookie string begin with the name we want?
	                if (cookie.substring(0, name.length + 1) == (name + '=')) {
	                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
	                    break;
	                }
	            }
	        }
	        return cookieValue;
	    }
	};

/***/ },
/* 4 */
/***/ function(module, exports) {

	/*! Magnific Popup - v0.9.9 - 2014-09-06
	 * http://dimsemenov.com/plugins/magnific-popup/
	 * Copyright (c) 2014 Dmitry Semenov; */
	(function(e){var t,n,i,o,r,a,s,l="Close",c="BeforeClose",d="AfterClose",u="BeforeAppend",p="MarkupParse",f="Open",m="Change",g="mfp",h="."+g,v="mfp-ready",C="mfp-removing",y="mfp-prevent-close",w=function(){},b=!!window.jQuery,I=e(window),x=function(e,n){t.ev.on(g+e+h,n)},k=function(t,n,i,o){var r=document.createElement("div");return r.className="mfp-"+t,i&&(r.innerHTML=i),o?n&&n.appendChild(r):(r=e(r),n&&r.appendTo(n)),r},T=function(n,i){t.ev.triggerHandler(g+n,i),t.st.callbacks&&(n=n.charAt(0).toLowerCase()+n.slice(1),t.st.callbacks[n]&&t.st.callbacks[n].apply(t,e.isArray(i)?i:[i]))},E=function(n){return n===s&&t.currTemplate.closeBtn||(t.currTemplate.closeBtn=e(t.st.closeMarkup.replace("%title%",t.st.tClose)),s=n),t.currTemplate.closeBtn},_=function(){e.magnificPopup.instance||(t=new w,t.init(),e.magnificPopup.instance=t)},S=function(){var e=document.createElement("p").style,t=["ms","O","Moz","Webkit"];if(void 0!==e.transition)return!0;for(;t.length;)if(t.pop()+"Transition"in e)return!0;return!1};w.prototype={constructor:w,init:function(){var n=navigator.appVersion;t.isIE7=-1!==n.indexOf("MSIE 7."),t.isIE8=-1!==n.indexOf("MSIE 8."),t.isLowIE=t.isIE7||t.isIE8,t.isAndroid=/android/gi.test(n),t.isIOS=/iphone|ipad|ipod/gi.test(n),t.supportsTransition=S(),t.probablyMobile=t.isAndroid||t.isIOS||/(Opera Mini)|Kindle|webOS|BlackBerry|(Opera Mobi)|(Windows Phone)|IEMobile/i.test(navigator.userAgent),o=e(document),t.popupsCache={}},open:function(n){i||(i=e(document.body));var r;if(n.isObj===!1){t.items=n.items.toArray(),t.index=0;var s,l=n.items;for(r=0;l.length>r;r++)if(s=l[r],s.parsed&&(s=s.el[0]),s===n.el[0]){t.index=r;break}}else t.items=e.isArray(n.items)?n.items:[n.items],t.index=n.index||0;if(t.isOpen)return t.updateItemHTML(),void 0;t.types=[],a="",t.ev=n.mainEl&&n.mainEl.length?n.mainEl.eq(0):o,n.key?(t.popupsCache[n.key]||(t.popupsCache[n.key]={}),t.currTemplate=t.popupsCache[n.key]):t.currTemplate={},t.st=e.extend(!0,{},e.magnificPopup.defaults,n),t.fixedContentPos="auto"===t.st.fixedContentPos?!t.probablyMobile:t.st.fixedContentPos,t.st.modal&&(t.st.closeOnContentClick=!1,t.st.closeOnBgClick=!1,t.st.showCloseBtn=!1,t.st.enableEscapeKey=!1),t.bgOverlay||(t.bgOverlay=k("bg").on("click"+h,function(){t.close()}),t.wrap=k("wrap").attr("tabindex",-1).on("click"+h,function(e){t._checkIfClose(e.target)&&t.close()}),t.container=k("container",t.wrap)),t.contentContainer=k("content"),t.st.preloader&&(t.preloader=k("preloader",t.container,t.st.tLoading));var c=e.magnificPopup.modules;for(r=0;c.length>r;r++){var d=c[r];d=d.charAt(0).toUpperCase()+d.slice(1),t["init"+d].call(t)}T("BeforeOpen"),t.st.showCloseBtn&&(t.st.closeBtnInside?(x(p,function(e,t,n,i){n.close_replaceWith=E(i.type)}),a+=" mfp-close-btn-in"):t.wrap.append(E())),t.st.alignTop&&(a+=" mfp-align-top"),t.fixedContentPos?t.wrap.css({overflow:t.st.overflowY,overflowX:"hidden",overflowY:t.st.overflowY}):t.wrap.css({top:I.scrollTop(),position:"absolute"}),(t.st.fixedBgPos===!1||"auto"===t.st.fixedBgPos&&!t.fixedContentPos)&&t.bgOverlay.css({height:o.height(),position:"absolute"}),t.st.enableEscapeKey&&o.on("keyup"+h,function(e){27===e.keyCode&&t.close()}),I.on("resize"+h,function(){t.updateSize()}),t.st.closeOnContentClick||(a+=" mfp-auto-cursor"),a&&t.wrap.addClass(a);var u=t.wH=I.height(),m={};if(t.fixedContentPos&&t._hasScrollBar(u)){var g=t._getScrollbarSize();g&&(m.marginRight=g)}t.fixedContentPos&&(t.isIE7?e("body, html").css("overflow","hidden"):m.overflow="hidden");var C=t.st.mainClass;return t.isIE7&&(C+=" mfp-ie7"),C&&t._addClassToMFP(C),t.updateItemHTML(),T("BuildControls"),e("html").css(m),t.bgOverlay.add(t.wrap).prependTo(t.st.prependTo||i),t._lastFocusedEl=document.activeElement,setTimeout(function(){t.content?(t._addClassToMFP(v),t._setFocus()):t.bgOverlay.addClass(v),o.on("focusin"+h,t._onFocusIn)},16),t.isOpen=!0,t.updateSize(u),T(f),n},close:function(){t.isOpen&&(T(c),t.isOpen=!1,t.st.removalDelay&&!t.isLowIE&&t.supportsTransition?(t._addClassToMFP(C),setTimeout(function(){t._close()},t.st.removalDelay)):t._close())},_close:function(){T(l);var n=C+" "+v+" ";if(t.bgOverlay.detach(),t.wrap.detach(),t.container.empty(),t.st.mainClass&&(n+=t.st.mainClass+" "),t._removeClassFromMFP(n),t.fixedContentPos){var i={marginRight:""};t.isIE7?e("body, html").css("overflow",""):i.overflow="",e("html").css(i)}o.off("keyup"+h+" focusin"+h),t.ev.off(h),t.wrap.attr("class","mfp-wrap").removeAttr("style"),t.bgOverlay.attr("class","mfp-bg"),t.container.attr("class","mfp-container"),!t.st.showCloseBtn||t.st.closeBtnInside&&t.currTemplate[t.currItem.type]!==!0||t.currTemplate.closeBtn&&t.currTemplate.closeBtn.detach(),t._lastFocusedEl&&e(t._lastFocusedEl).focus(),t.currItem=null,t.content=null,t.currTemplate=null,t.prevHeight=0,T(d)},updateSize:function(e){if(t.isIOS){var n=document.documentElement.clientWidth/window.innerWidth,i=window.innerHeight*n;t.wrap.css("height",i),t.wH=i}else t.wH=e||I.height();t.fixedContentPos||t.wrap.css("height",t.wH),T("Resize")},updateItemHTML:function(){var n=t.items[t.index];t.contentContainer.detach(),t.content&&t.content.detach(),n.parsed||(n=t.parseEl(t.index));var i=n.type;if(T("BeforeChange",[t.currItem?t.currItem.type:"",i]),t.currItem=n,!t.currTemplate[i]){var o=t.st[i]?t.st[i].markup:!1;T("FirstMarkupParse",o),t.currTemplate[i]=o?e(o):!0}r&&r!==n.type&&t.container.removeClass("mfp-"+r+"-holder");var a=t["get"+i.charAt(0).toUpperCase()+i.slice(1)](n,t.currTemplate[i]);t.appendContent(a,i),n.preloaded=!0,T(m,n),r=n.type,t.container.prepend(t.contentContainer),T("AfterChange")},appendContent:function(e,n){t.content=e,e?t.st.showCloseBtn&&t.st.closeBtnInside&&t.currTemplate[n]===!0?t.content.find(".mfp-close").length||t.content.append(E()):t.content=e:t.content="",T(u),t.container.addClass("mfp-"+n+"-holder"),t.contentContainer.append(t.content)},parseEl:function(n){var i,o=t.items[n];if(o.tagName?o={el:e(o)}:(i=o.type,o={data:o,src:o.src}),o.el){for(var r=t.types,a=0;r.length>a;a++)if(o.el.hasClass("mfp-"+r[a])){i=r[a];break}o.src=o.el.attr("data-mfp-src"),o.src||(o.src=o.el.attr("href"))}return o.type=i||t.st.type||"inline",o.index=n,o.parsed=!0,t.items[n]=o,T("ElementParse",o),t.items[n]},addGroup:function(e,n){var i=function(i){i.mfpEl=this,t._openClick(i,e,n)};n||(n={});var o="click.magnificPopup";n.mainEl=e,n.items?(n.isObj=!0,e.off(o).on(o,i)):(n.isObj=!1,n.delegate?e.off(o).on(o,n.delegate,i):(n.items=e,e.off(o).on(o,i)))},_openClick:function(n,i,o){var r=void 0!==o.midClick?o.midClick:e.magnificPopup.defaults.midClick;if(r||2!==n.which&&!n.ctrlKey&&!n.metaKey){var a=void 0!==o.disableOn?o.disableOn:e.magnificPopup.defaults.disableOn;if(a)if(e.isFunction(a)){if(!a.call(t))return!0}else if(a>I.width())return!0;n.type&&(n.preventDefault(),t.isOpen&&n.stopPropagation()),o.el=e(n.mfpEl),o.delegate&&(o.items=i.find(o.delegate)),t.open(o)}},updateStatus:function(e,i){if(t.preloader){n!==e&&t.container.removeClass("mfp-s-"+n),i||"loading"!==e||(i=t.st.tLoading);var o={status:e,text:i};T("UpdateStatus",o),e=o.status,i=o.text,t.preloader.html(i),t.preloader.find("a").on("click",function(e){e.stopImmediatePropagation()}),t.container.addClass("mfp-s-"+e),n=e}},_checkIfClose:function(n){if(!e(n).hasClass(y)){var i=t.st.closeOnContentClick,o=t.st.closeOnBgClick;if(i&&o)return!0;if(!t.content||e(n).hasClass("mfp-close")||t.preloader&&n===t.preloader[0])return!0;if(n===t.content[0]||e.contains(t.content[0],n)){if(i)return!0}else if(o&&e.contains(document,n))return!0;return!1}},_addClassToMFP:function(e){t.bgOverlay.addClass(e),t.wrap.addClass(e)},_removeClassFromMFP:function(e){this.bgOverlay.removeClass(e),t.wrap.removeClass(e)},_hasScrollBar:function(e){return(t.isIE7?o.height():document.body.scrollHeight)>(e||I.height())},_setFocus:function(){(t.st.focus?t.content.find(t.st.focus).eq(0):t.wrap).focus()},_onFocusIn:function(n){return n.target===t.wrap[0]||e.contains(t.wrap[0],n.target)?void 0:(t._setFocus(),!1)},_parseMarkup:function(t,n,i){var o;i.data&&(n=e.extend(i.data,n)),T(p,[t,n,i]),e.each(n,function(e,n){if(void 0===n||n===!1)return!0;if(o=e.split("_"),o.length>1){var i=t.find(h+"-"+o[0]);if(i.length>0){var r=o[1];"replaceWith"===r?i[0]!==n[0]&&i.replaceWith(n):"img"===r?i.is("img")?i.attr("src",n):i.replaceWith('<img src="'+n+'" class="'+i.attr("class")+'" />'):i.attr(o[1],n)}}else t.find(h+"-"+e).html(n)})},_getScrollbarSize:function(){if(void 0===t.scrollbarSize){var e=document.createElement("div");e.style.cssText="width: 99px; height: 99px; overflow: scroll; position: absolute; top: -9999px;",document.body.appendChild(e),t.scrollbarSize=e.offsetWidth-e.clientWidth,document.body.removeChild(e)}return t.scrollbarSize}},e.magnificPopup={instance:null,proto:w.prototype,modules:[],open:function(t,n){return _(),t=t?e.extend(!0,{},t):{},t.isObj=!0,t.index=n||0,this.instance.open(t)},close:function(){return e.magnificPopup.instance&&e.magnificPopup.instance.close()},registerModule:function(t,n){n.options&&(e.magnificPopup.defaults[t]=n.options),e.extend(this.proto,n.proto),this.modules.push(t)},defaults:{disableOn:0,key:null,midClick:!1,mainClass:"",preloader:!0,focus:"",closeOnContentClick:!1,closeOnBgClick:!0,closeBtnInside:!0,showCloseBtn:!0,enableEscapeKey:!0,modal:!1,alignTop:!1,removalDelay:0,prependTo:null,fixedContentPos:"auto",fixedBgPos:"auto",overflowY:"auto",closeMarkup:'<button title="%title%" type="button" class="mfp-close">&times;</button>',tClose:"Close (Esc)",tLoading:"Loading..."}},e.fn.magnificPopup=function(n){_();var i=e(this);if("string"==typeof n)if("open"===n){var o,r=b?i.data("magnificPopup"):i[0].magnificPopup,a=parseInt(arguments[1],10)||0;r.items?o=r.items[a]:(o=i,r.delegate&&(o=o.find(r.delegate)),o=o.eq(a)),t._openClick({mfpEl:o},i,r)}else t.isOpen&&t[n].apply(t,Array.prototype.slice.call(arguments,1));else n=e.extend(!0,{},n),b?i.data("magnificPopup",n):i[0].magnificPopup=n,t.addGroup(i,n);return i};var P,O,z,M="inline",B=function(){z&&(O.after(z.addClass(P)).detach(),z=null)};e.magnificPopup.registerModule(M,{options:{hiddenClass:"hide",markup:"",tNotFound:"Content not found"},proto:{initInline:function(){t.types.push(M),x(l+"."+M,function(){B()})},getInline:function(n,i){if(B(),n.src){var o=t.st.inline,r=e(n.src);if(r.length){var a=r[0].parentNode;a&&a.tagName&&(O||(P=o.hiddenClass,O=k(P),P="mfp-"+P),z=r.after(O).detach().removeClass(P)),t.updateStatus("ready")}else t.updateStatus("error",o.tNotFound),r=e("<div>");return n.inlineElement=r,r}return t.updateStatus("ready"),t._parseMarkup(i,{},n),i}}});var F,H="ajax",L=function(){F&&i.removeClass(F)},A=function(){L(),t.req&&t.req.abort()};e.magnificPopup.registerModule(H,{options:{settings:null,cursor:"mfp-ajax-cur",tError:'<a href="%url%">The content</a> could not be loaded.'},proto:{initAjax:function(){t.types.push(H),F=t.st.ajax.cursor,x(l+"."+H,A),x("BeforeChange."+H,A)},getAjax:function(n){F&&i.addClass(F),t.updateStatus("loading");var o=e.extend({url:n.src,success:function(i,o,r){var a={data:i,xhr:r};T("ParseAjax",a),t.appendContent(e(a.data),H),n.finished=!0,L(),t._setFocus(),setTimeout(function(){t.wrap.addClass(v)},16),t.updateStatus("ready"),T("AjaxContentAdded")},error:function(){L(),n.finished=n.loadError=!0,t.updateStatus("error",t.st.ajax.tError.replace("%url%",n.src))}},t.st.ajax.settings);return t.req=e.ajax(o),""}}});var j,N=function(n){if(n.data&&void 0!==n.data.title)return n.data.title;var i=t.st.image.titleSrc;if(i){if(e.isFunction(i))return i.call(t,n);if(n.el)return n.el.attr(i)||""}return""};e.magnificPopup.registerModule("image",{options:{markup:'<div class="mfp-figure"><div class="mfp-close"></div><figure><div class="mfp-img"></div><figcaption><div class="mfp-bottom-bar"><div class="mfp-title"></div><div class="mfp-counter"></div></div></figcaption></figure></div>',cursor:"mfp-zoom-out-cur",titleSrc:"title",verticalFit:!0,tError:'<a href="%url%">The image</a> could not be loaded.'},proto:{initImage:function(){var e=t.st.image,n=".image";t.types.push("image"),x(f+n,function(){"image"===t.currItem.type&&e.cursor&&i.addClass(e.cursor)}),x(l+n,function(){e.cursor&&i.removeClass(e.cursor),I.off("resize"+h)}),x("Resize"+n,t.resizeImage),t.isLowIE&&x("AfterChange",t.resizeImage)},resizeImage:function(){var e=t.currItem;if(e&&e.img&&t.st.image.verticalFit){var n=0;t.isLowIE&&(n=parseInt(e.img.css("padding-top"),10)+parseInt(e.img.css("padding-bottom"),10)),e.img.css("max-height",t.wH-n)}},_onImageHasSize:function(e){e.img&&(e.hasSize=!0,j&&clearInterval(j),e.isCheckingImgSize=!1,T("ImageHasSize",e),e.imgHidden&&(t.content&&t.content.removeClass("mfp-loading"),e.imgHidden=!1))},findImageSize:function(e){var n=0,i=e.img[0],o=function(r){j&&clearInterval(j),j=setInterval(function(){return i.naturalWidth>0?(t._onImageHasSize(e),void 0):(n>200&&clearInterval(j),n++,3===n?o(10):40===n?o(50):100===n&&o(500),void 0)},r)};o(1)},getImage:function(n,i){var o=0,r=function(){n&&(n.img[0].complete?(n.img.off(".mfploader"),n===t.currItem&&(t._onImageHasSize(n),t.updateStatus("ready")),n.hasSize=!0,n.loaded=!0,T("ImageLoadComplete")):(o++,200>o?setTimeout(r,100):a()))},a=function(){n&&(n.img.off(".mfploader"),n===t.currItem&&(t._onImageHasSize(n),t.updateStatus("error",s.tError.replace("%url%",n.src))),n.hasSize=!0,n.loaded=!0,n.loadError=!0)},s=t.st.image,l=i.find(".mfp-img");if(l.length){var c=document.createElement("img");c.className="mfp-img",n.img=e(c).on("load.mfploader",r).on("error.mfploader",a),c.src=n.src,l.is("img")&&(n.img=n.img.clone()),c=n.img[0],c.naturalWidth>0?n.hasSize=!0:c.width||(n.hasSize=!1)}return t._parseMarkup(i,{title:N(n),img_replaceWith:n.img},n),t.resizeImage(),n.hasSize?(j&&clearInterval(j),n.loadError?(i.addClass("mfp-loading"),t.updateStatus("error",s.tError.replace("%url%",n.src))):(i.removeClass("mfp-loading"),t.updateStatus("ready")),i):(t.updateStatus("loading"),n.loading=!0,n.hasSize||(n.imgHidden=!0,i.addClass("mfp-loading"),t.findImageSize(n)),i)}}});var W,R=function(){return void 0===W&&(W=void 0!==document.createElement("p").style.MozTransform),W};e.magnificPopup.registerModule("zoom",{options:{enabled:!1,easing:"ease-in-out",duration:300,opener:function(e){return e.is("img")?e:e.find("img")}},proto:{initZoom:function(){var e,n=t.st.zoom,i=".zoom";if(n.enabled&&t.supportsTransition){var o,r,a=n.duration,s=function(e){var t=e.clone().removeAttr("style").removeAttr("class").addClass("mfp-animated-image"),i="all "+n.duration/1e3+"s "+n.easing,o={position:"fixed",zIndex:9999,left:0,top:0,"-webkit-backface-visibility":"hidden"},r="transition";return o["-webkit-"+r]=o["-moz-"+r]=o["-o-"+r]=o[r]=i,t.css(o),t},d=function(){t.content.css("visibility","visible")};x("BuildControls"+i,function(){if(t._allowZoom()){if(clearTimeout(o),t.content.css("visibility","hidden"),e=t._getItemToZoom(),!e)return d(),void 0;r=s(e),r.css(t._getOffset()),t.wrap.append(r),o=setTimeout(function(){r.css(t._getOffset(!0)),o=setTimeout(function(){d(),setTimeout(function(){r.remove(),e=r=null,T("ZoomAnimationEnded")},16)},a)},16)}}),x(c+i,function(){if(t._allowZoom()){if(clearTimeout(o),t.st.removalDelay=a,!e){if(e=t._getItemToZoom(),!e)return;r=s(e)}r.css(t._getOffset(!0)),t.wrap.append(r),t.content.css("visibility","hidden"),setTimeout(function(){r.css(t._getOffset())},16)}}),x(l+i,function(){t._allowZoom()&&(d(),r&&r.remove(),e=null)})}},_allowZoom:function(){return"image"===t.currItem.type},_getItemToZoom:function(){return t.currItem.hasSize?t.currItem.img:!1},_getOffset:function(n){var i;i=n?t.currItem.img:t.st.zoom.opener(t.currItem.el||t.currItem);var o=i.offset(),r=parseInt(i.css("padding-top"),10),a=parseInt(i.css("padding-bottom"),10);o.top-=e(window).scrollTop()-r;var s={width:i.width(),height:(b?i.innerHeight():i[0].offsetHeight)-a-r};return R()?s["-moz-transform"]=s.transform="translate("+o.left+"px,"+o.top+"px)":(s.left=o.left,s.top=o.top),s}}});var Z="iframe",q="//about:blank",D=function(e){if(t.currTemplate[Z]){var n=t.currTemplate[Z].find("iframe");n.length&&(e||(n[0].src=q),t.isIE8&&n.css("display",e?"block":"none"))}};e.magnificPopup.registerModule(Z,{options:{markup:'<div class="mfp-iframe-scaler"><div class="mfp-close"></div><iframe class="mfp-iframe" src="//about:blank" frameborder="0" allowfullscreen></iframe></div>',srcAction:"iframe_src",patterns:{youtube:{index:"youtube.com",id:"v=",src:"//www.youtube.com/embed/%id%?autoplay=1"},vimeo:{index:"vimeo.com/",id:"/",src:"//player.vimeo.com/video/%id%?autoplay=1"},gmaps:{index:"//maps.google.",src:"%id%&output=embed"}}},proto:{initIframe:function(){t.types.push(Z),x("BeforeChange",function(e,t,n){t!==n&&(t===Z?D():n===Z&&D(!0))}),x(l+"."+Z,function(){D()})},getIframe:function(n,i){var o=n.src,r=t.st.iframe;e.each(r.patterns,function(){return o.indexOf(this.index)>-1?(this.id&&(o="string"==typeof this.id?o.substr(o.lastIndexOf(this.id)+this.id.length,o.length):this.id.call(this,o)),o=this.src.replace("%id%",o),!1):void 0});var a={};return r.srcAction&&(a[r.srcAction]=o),t._parseMarkup(i,a,n),t.updateStatus("ready"),i}}});var K=function(e){var n=t.items.length;return e>n-1?e-n:0>e?n+e:e},Y=function(e,t,n){return e.replace(/%curr%/gi,t+1).replace(/%total%/gi,n)};e.magnificPopup.registerModule("gallery",{options:{enabled:!1,arrowMarkup:'<button title="%title%" type="button" class="mfp-arrow mfp-arrow-%dir%"></button>',preload:[0,2],navigateByImgClick:!0,arrows:!0,tPrev:"Previous (Left arrow key)",tNext:"Next (Right arrow key)",tCounter:"%curr% of %total%"},proto:{initGallery:function(){var n=t.st.gallery,i=".mfp-gallery",r=Boolean(e.fn.mfpFastClick);return t.direction=!0,n&&n.enabled?(a+=" mfp-gallery",x(f+i,function(){n.navigateByImgClick&&t.wrap.on("click"+i,".mfp-img",function(){return t.items.length>1?(t.next(),!1):void 0}),o.on("keydown"+i,function(e){37===e.keyCode?t.prev():39===e.keyCode&&t.next()})}),x("UpdateStatus"+i,function(e,n){n.text&&(n.text=Y(n.text,t.currItem.index,t.items.length))}),x(p+i,function(e,i,o,r){var a=t.items.length;o.counter=a>1?Y(n.tCounter,r.index,a):""}),x("BuildControls"+i,function(){if(t.items.length>1&&n.arrows&&!t.arrowLeft){var i=n.arrowMarkup,o=t.arrowLeft=e(i.replace(/%title%/gi,n.tPrev).replace(/%dir%/gi,"left")).addClass(y),a=t.arrowRight=e(i.replace(/%title%/gi,n.tNext).replace(/%dir%/gi,"right")).addClass(y),s=r?"mfpFastClick":"click";o[s](function(){t.prev()}),a[s](function(){t.next()}),t.isIE7&&(k("b",o[0],!1,!0),k("a",o[0],!1,!0),k("b",a[0],!1,!0),k("a",a[0],!1,!0)),t.container.append(o.add(a))}}),x(m+i,function(){t._preloadTimeout&&clearTimeout(t._preloadTimeout),t._preloadTimeout=setTimeout(function(){t.preloadNearbyImages(),t._preloadTimeout=null},16)}),x(l+i,function(){o.off(i),t.wrap.off("click"+i),t.arrowLeft&&r&&t.arrowLeft.add(t.arrowRight).destroyMfpFastClick(),t.arrowRight=t.arrowLeft=null}),void 0):!1},next:function(){t.direction=!0,t.index=K(t.index+1),t.updateItemHTML()},prev:function(){t.direction=!1,t.index=K(t.index-1),t.updateItemHTML()},goTo:function(e){t.direction=e>=t.index,t.index=e,t.updateItemHTML()},preloadNearbyImages:function(){var e,n=t.st.gallery.preload,i=Math.min(n[0],t.items.length),o=Math.min(n[1],t.items.length);for(e=1;(t.direction?o:i)>=e;e++)t._preloadItem(t.index+e);for(e=1;(t.direction?i:o)>=e;e++)t._preloadItem(t.index-e)},_preloadItem:function(n){if(n=K(n),!t.items[n].preloaded){var i=t.items[n];i.parsed||(i=t.parseEl(n)),T("LazyLoad",i),"image"===i.type&&(i.img=e('<img class="mfp-img" />').on("load.mfploader",function(){i.hasSize=!0}).on("error.mfploader",function(){i.hasSize=!0,i.loadError=!0,T("LazyLoadError",i)}).attr("src",i.src)),i.preloaded=!0}}}});var U="retina";e.magnificPopup.registerModule(U,{options:{replaceSrc:function(e){return e.src.replace(/\.\w+$/,function(e){return"@2x"+e})},ratio:1},proto:{initRetina:function(){if(window.devicePixelRatio>1){var e=t.st.retina,n=e.ratio;n=isNaN(n)?n():n,n>1&&(x("ImageHasSize."+U,function(e,t){t.img.css({"max-width":t.img[0].naturalWidth/n,width:"100%"})}),x("ElementParse."+U,function(t,i){i.src=e.replaceSrc(i,n)}))}}}}),function(){var t=1e3,n="ontouchstart"in window,i=function(){I.off("touchmove"+r+" touchend"+r)},o="mfpFastClick",r="."+o;e.fn.mfpFastClick=function(o){return e(this).each(function(){var a,s=e(this);if(n){var l,c,d,u,p,f;s.on("touchstart"+r,function(e){u=!1,f=1,p=e.originalEvent?e.originalEvent.touches[0]:e.touches[0],c=p.clientX,d=p.clientY,I.on("touchmove"+r,function(e){p=e.originalEvent?e.originalEvent.touches:e.touches,f=p.length,p=p[0],(Math.abs(p.clientX-c)>10||Math.abs(p.clientY-d)>10)&&(u=!0,i())}).on("touchend"+r,function(e){i(),u||f>1||(a=!0,e.preventDefault(),clearTimeout(l),l=setTimeout(function(){a=!1},t),o())})})}s.on("click"+r,function(){a||o()})})},e.fn.destroyMfpFastClick=function(){e(this).off("touchstart"+r+" click"+r),n&&I.off("touchmove"+r+" touchend"+r)}}(),_()})(window.jQuery||window.Zepto);

/***/ },
/* 5 */
/***/ function(module, exports) {

	;(function($, window, document, undefined) {

	    var pluginName = 'stellar',
	        defaults = {
	            scrollProperty: 'scroll',
	            positionProperty: 'position',
	            horizontalScrolling: true,
	            verticalScrolling: true,
	            horizontalOffset: 0,
	            verticalOffset: 0,
	            responsive: false,
	            parallaxBackgrounds: true,
	            parallaxElements: true,
	            hideDistantElements: true,
	            hideElement: function($elem) { $elem.hide(); },
	            showElement: function($elem) { $elem.show(); }
	        },

	        scrollProperty = {
	            scroll: {
	                getLeft: function($elem) { return $elem.scrollLeft(); },
	                setLeft: function($elem, val) { $elem.scrollLeft(val); },

	                getTop: function($elem) { return $elem.scrollTop();	},
	                setTop: function($elem, val) { $elem.scrollTop(val); }
	            },
	            position: {
	                getLeft: function($elem) { return parseInt($elem.css('left'), 10) * -1; },
	                getTop: function($elem) { return parseInt($elem.css('top'), 10) * -1; }
	            },
	            margin: {
	                getLeft: function($elem) { return parseInt($elem.css('margin-left'), 10) * -1; },
	                getTop: function($elem) { return parseInt($elem.css('margin-top'), 10) * -1; }
	            },
	            transform: {
	                getLeft: function($elem) {
	                    var computedTransform = getComputedStyle($elem[0])[prefixedTransform];
	                    return (computedTransform !== 'none' ? parseInt(computedTransform.match(/(-?[0-9]+)/g)[4], 10) * -1 : 0);
	                },
	                getTop: function($elem) {
	                    var computedTransform = getComputedStyle($elem[0])[prefixedTransform];
	                    return (computedTransform !== 'none' ? parseInt(computedTransform.match(/(-?[0-9]+)/g)[5], 10) * -1 : 0);
	                }
	            }
	        },

	        positionProperty = {
	            position: {
	                setLeft: function($elem, left) { $elem.css('left', left); },
	                setTop: function($elem, top) { $elem.css('top', top); }
	            },
	            transform: {
	                setPosition: function($elem, left, startingLeft, top, startingTop) {
	                    $elem[0].style[prefixedTransform] = 'translate3d(' + (left - startingLeft) + 'px, ' + (top - startingTop) + 'px, 0)';
	                }
	            }
	        },

	        // Returns a function which adds a vendor prefix to any CSS property name
	        vendorPrefix = (function() {
	            var prefixes = /^(Moz|Webkit|Khtml|O|ms|Icab)(?=[A-Z])/,
	                style = $('script')[0].style,
	                prefix = '',
	                prop;

	            for (prop in style) {
	                if (prefixes.test(prop)) {
	                    prefix = prop.match(prefixes)[0];
	                    break;
	                }
	            }

	            if ('WebkitOpacity' in style) { prefix = 'Webkit'; }
	            if ('KhtmlOpacity' in style) { prefix = 'Khtml'; }

	            return function(property) {
	                return prefix + (prefix.length > 0 ? property.charAt(0).toUpperCase() + property.slice(1) : property);
	            };
	        }()),

	        prefixedTransform = vendorPrefix('transform'),

	        supportsBackgroundPositionXY = $('<div />', { style: 'background:#fff' }).css('background-position-x') !== undefined,

	        setBackgroundPosition = (supportsBackgroundPositionXY ?
	                function($elem, x, y) {
	                    $elem.css({
	                        'background-position-x': x,
	                        'background-position-y': y
	                    });
	                } :
	                function($elem, x, y) {
	                    $elem.css('background-position', x + ' ' + y);
	                }
	        ),

	        getBackgroundPosition = (supportsBackgroundPositionXY ?
	                function($elem) {
	                    return [
	                        $elem.css('background-position-x'),
	                        $elem.css('background-position-y')
	                    ];
	                } :
	                function($elem) {
	                    return $elem.css('background-position').split(' ');
	                }
	        ),

	        requestAnimFrame = (
	            window.requestAnimationFrame       ||
	            window.webkitRequestAnimationFrame ||
	            window.mozRequestAnimationFrame    ||
	            window.oRequestAnimationFrame      ||
	            window.msRequestAnimationFrame     ||
	            function(callback) {
	                setTimeout(callback, 1000 / 60);
	            }
	        );

	    function Plugin(element, options) {
	        this.element = element;
	        this.options = $.extend({}, defaults, options);

	        this._defaults = defaults;
	        this._name = pluginName;

	        this.init();
	    }

	    Plugin.prototype = {
	        init: function() {
	            this.options.name = pluginName + '_' + Math.floor(Math.random() * 1e9);

	            this._defineElements();
	            this._defineGetters();
	            this._defineSetters();
	            this._handleWindowLoadAndResize();
	            this._detectViewport();

	            this.refresh({ firstLoad: true });

	            if (this.options.scrollProperty === 'scroll') {
	                this._handleScrollEvent();
	            } else {
	                this._startAnimationLoop();
	            }
	        },
	        _defineElements: function() {
	            if (this.element === document.body) this.element = window;
	            this.$scrollElement = $(this.element);
	            this.$element = (this.element === window ? $('body') : this.$scrollElement);
	            this.$viewportElement = (this.options.viewportElement !== undefined ? $(this.options.viewportElement) : (this.$scrollElement[0] === window || this.options.scrollProperty === 'scroll' ? this.$scrollElement : this.$scrollElement.parent()) );
	        },
	        _defineGetters: function() {
	            var self = this,
	                scrollPropertyAdapter = scrollProperty[self.options.scrollProperty];

	            this._getScrollLeft = function() {
	                return scrollPropertyAdapter.getLeft(self.$scrollElement);
	            };

	            this._getScrollTop = function() {
	                return scrollPropertyAdapter.getTop(self.$scrollElement);
	            };
	        },
	        _defineSetters: function() {
	            var self = this,
	                scrollPropertyAdapter = scrollProperty[self.options.scrollProperty],
	                positionPropertyAdapter = positionProperty[self.options.positionProperty],
	                setScrollLeft = scrollPropertyAdapter.setLeft,
	                setScrollTop = scrollPropertyAdapter.setTop;

	            this._setScrollLeft = (typeof setScrollLeft === 'function' ? function(val) {
	                setScrollLeft(self.$scrollElement, val);
	            } : $.noop);

	            this._setScrollTop = (typeof setScrollTop === 'function' ? function(val) {
	                setScrollTop(self.$scrollElement, val);
	            } : $.noop);

	            this._setPosition = positionPropertyAdapter.setPosition ||
	                function($elem, left, startingLeft, top, startingTop) {
	                    if (self.options.horizontalScrolling) {
	                        positionPropertyAdapter.setLeft($elem, left, startingLeft);
	                    }

	                    if (self.options.verticalScrolling) {
	                        positionPropertyAdapter.setTop($elem, top, startingTop);
	                    }
	                };
	        },
	        _handleWindowLoadAndResize: function() {
	            var self = this,
	                $window = $(window);

	            if (self.options.responsive) {
	                $window.bind('load.' + this.name, function() {
	                    self.refresh();
	                });
	            }

	            $window.bind('resize.' + this.name, function() {
	                self._detectViewport();

	                if (self.options.responsive) {
	                    self.refresh();
	                }
	            });
	        },
	        refresh: function(options) {
	            var self = this,
	                oldLeft = self._getScrollLeft(),
	                oldTop = self._getScrollTop();

	            if (!options || !options.firstLoad) {
	                this._reset();
	            }

	            this._setScrollLeft(0);
	            this._setScrollTop(0);

	            this._setOffsets();
	            this._findParticles();
	            this._findBackgrounds();

	            // Fix for WebKit background rendering bug
	            if (options && options.firstLoad && /WebKit/.test(navigator.userAgent)) {
	                $(window).load(function() {
	                    var oldLeft = self._getScrollLeft(),
	                        oldTop = self._getScrollTop();

	                    self._setScrollLeft(oldLeft + 1);
	                    self._setScrollTop(oldTop + 1);

	                    self._setScrollLeft(oldLeft);
	                    self._setScrollTop(oldTop);
	                });
	            }

	            this._setScrollLeft(oldLeft);
	            this._setScrollTop(oldTop);
	        },
	        _detectViewport: function() {
	            var viewportOffsets = this.$viewportElement.offset(),
	                hasOffsets = viewportOffsets !== null && viewportOffsets !== undefined;

	            this.viewportWidth = this.$viewportElement.width();
	            this.viewportHeight = this.$viewportElement.height();

	            this.viewportOffsetTop = (hasOffsets ? viewportOffsets.top : 0);
	            this.viewportOffsetLeft = (hasOffsets ? viewportOffsets.left : 0);
	        },
	        _findParticles: function() {
	            var self = this,
	                scrollLeft = this._getScrollLeft(),
	                scrollTop = this._getScrollTop();

	            if (this.particles !== undefined) {
	                for (var i = this.particles.length - 1; i >= 0; i--) {
	                    this.particles[i].$element.data('stellar-elementIsActive', undefined);
	                }
	            }

	            this.particles = [];

	            if (!this.options.parallaxElements) return;

	            this.$element.find('[data-stellar-ratio]').each(function(i) {
	                var $this = $(this),
	                    horizontalOffset,
	                    verticalOffset,
	                    positionLeft,
	                    positionTop,
	                    marginLeft,
	                    marginTop,
	                    $offsetParent,
	                    offsetLeft,
	                    offsetTop,
	                    parentOffsetLeft = 0,
	                    parentOffsetTop = 0,
	                    tempParentOffsetLeft = 0,
	                    tempParentOffsetTop = 0;

	                // Ensure this element isn't already part of another scrolling element
	                if (!$this.data('stellar-elementIsActive')) {
	                    $this.data('stellar-elementIsActive', this);
	                } else if ($this.data('stellar-elementIsActive') !== this) {
	                    return;
	                }

	                self.options.showElement($this);

	                // Save/restore the original top and left CSS values in case we refresh the particles or destroy the instance
	                if (!$this.data('stellar-startingLeft')) {
	                    $this.data('stellar-startingLeft', $this.css('left'));
	                    $this.data('stellar-startingTop', $this.css('top'));
	                } else {
	                    $this.css('left', $this.data('stellar-startingLeft'));
	                    $this.css('top', $this.data('stellar-startingTop'));
	                }

	                positionLeft = $this.position().left;
	                positionTop = $this.position().top;

	                // Catch-all for margin top/left properties (these evaluate to 'auto' in IE7 and IE8)
	                marginLeft = ($this.css('margin-left') === 'auto') ? 0 : parseInt($this.css('margin-left'), 10);
	                marginTop = ($this.css('margin-top') === 'auto') ? 0 : parseInt($this.css('margin-top'), 10);

	                offsetLeft = $this.offset().left - marginLeft;
	                offsetTop = $this.offset().top - marginTop;

	                // Calculate the offset parent
	                $this.parents().each(function() {
	                    var $this = $(this);

	                    if ($this.data('stellar-offset-parent') === true) {
	                        parentOffsetLeft = tempParentOffsetLeft;
	                        parentOffsetTop = tempParentOffsetTop;
	                        $offsetParent = $this;

	                        return false;
	                    } else {
	                        tempParentOffsetLeft += $this.position().left;
	                        tempParentOffsetTop += $this.position().top;
	                    }
	                });

	                // Detect the offsets
	                horizontalOffset = ($this.data('stellar-horizontal-offset') !== undefined ? $this.data('stellar-horizontal-offset') : ($offsetParent !== undefined && $offsetParent.data('stellar-horizontal-offset') !== undefined ? $offsetParent.data('stellar-horizontal-offset') : self.horizontalOffset));
	                verticalOffset = ($this.data('stellar-vertical-offset') !== undefined ? $this.data('stellar-vertical-offset') : ($offsetParent !== undefined && $offsetParent.data('stellar-vertical-offset') !== undefined ? $offsetParent.data('stellar-vertical-offset') : self.verticalOffset));

	                // Add our object to the particles collection
	                self.particles.push({
	                    $element: $this,
	                    $offsetParent: $offsetParent,
	                    isFixed: $this.css('position') === 'fixed',
	                    horizontalOffset: horizontalOffset,
	                    verticalOffset: verticalOffset,
	                    startingPositionLeft: positionLeft,
	                    startingPositionTop: positionTop,
	                    startingOffsetLeft: offsetLeft,
	                    startingOffsetTop: offsetTop,
	                    parentOffsetLeft: parentOffsetLeft,
	                    parentOffsetTop: parentOffsetTop,
	                    stellarRatio: ($this.data('stellar-ratio') !== undefined ? $this.data('stellar-ratio') : 1),
	                    width: $this.outerWidth(true),
	                    height: $this.outerHeight(true),
	                    isHidden: false
	                });
	            });
	        },
	        _findBackgrounds: function() {
	            var self = this,
	                scrollLeft = this._getScrollLeft(),
	                scrollTop = this._getScrollTop(),
	                $backgroundElements;

	            this.backgrounds = [];

	            if (!this.options.parallaxBackgrounds) return;

	            $backgroundElements = this.$element.find('[data-stellar-background-ratio]');

	            if (this.$element.data('stellar-background-ratio')) {
	                $backgroundElements = $backgroundElements.add(this.$element);
	            }

	            $backgroundElements.each(function() {
	                var $this = $(this),
	                    backgroundPosition = getBackgroundPosition($this),
	                    horizontalOffset,
	                    verticalOffset,
	                    positionLeft,
	                    positionTop,
	                    marginLeft,
	                    marginTop,
	                    offsetLeft,
	                    offsetTop,
	                    $offsetParent,
	                    parentOffsetLeft = 0,
	                    parentOffsetTop = 0,
	                    tempParentOffsetLeft = 0,
	                    tempParentOffsetTop = 0;

	                // Ensure this element isn't already part of another scrolling element
	                if (!$this.data('stellar-backgroundIsActive')) {
	                    $this.data('stellar-backgroundIsActive', this);
	                } else if ($this.data('stellar-backgroundIsActive') !== this) {
	                    return;
	                }

	                // Save/restore the original top and left CSS values in case we destroy the instance
	                if (!$this.data('stellar-backgroundStartingLeft')) {
	                    $this.data('stellar-backgroundStartingLeft', backgroundPosition[0]);
	                    $this.data('stellar-backgroundStartingTop', backgroundPosition[1]);
	                } else {
	                    setBackgroundPosition($this, $this.data('stellar-backgroundStartingLeft'), $this.data('stellar-backgroundStartingTop'));
	                }

	                // Catch-all for margin top/left properties (these evaluate to 'auto' in IE7 and IE8)
	                marginLeft = ($this.css('margin-left') === 'auto') ? 0 : parseInt($this.css('margin-left'), 10);
	                marginTop = ($this.css('margin-top') === 'auto') ? 0 : parseInt($this.css('margin-top'), 10);

	                offsetLeft = $this.offset().left - marginLeft - scrollLeft;
	                offsetTop = $this.offset().top - marginTop - scrollTop;

	                // Calculate the offset parent
	                $this.parents().each(function() {
	                    var $this = $(this);

	                    if ($this.data('stellar-offset-parent') === true) {
	                        parentOffsetLeft = tempParentOffsetLeft;
	                        parentOffsetTop = tempParentOffsetTop;
	                        $offsetParent = $this;

	                        return false;
	                    } else {
	                        tempParentOffsetLeft += $this.position().left;
	                        tempParentOffsetTop += $this.position().top;
	                    }
	                });

	                // Detect the offsets
	                horizontalOffset = ($this.data('stellar-horizontal-offset') !== undefined ? $this.data('stellar-horizontal-offset') : ($offsetParent !== undefined && $offsetParent.data('stellar-horizontal-offset') !== undefined ? $offsetParent.data('stellar-horizontal-offset') : self.horizontalOffset));
	                verticalOffset = ($this.data('stellar-vertical-offset') !== undefined ? $this.data('stellar-vertical-offset') : ($offsetParent !== undefined && $offsetParent.data('stellar-vertical-offset') !== undefined ? $offsetParent.data('stellar-vertical-offset') : self.verticalOffset));

	                self.backgrounds.push({
	                    $element: $this,
	                    $offsetParent: $offsetParent,
	                    isFixed: $this.css('background-attachment') === 'fixed',
	                    horizontalOffset: horizontalOffset,
	                    verticalOffset: verticalOffset,
	                    startingValueLeft: backgroundPosition[0],
	                    startingValueTop: backgroundPosition[1],
	                    startingBackgroundPositionLeft: (isNaN(parseInt(backgroundPosition[0], 10)) ? 0 : parseInt(backgroundPosition[0], 10)),
	                    startingBackgroundPositionTop: (isNaN(parseInt(backgroundPosition[1], 10)) ? 0 : parseInt(backgroundPosition[1], 10)),
	                    startingPositionLeft: $this.position().left,
	                    startingPositionTop: $this.position().top,
	                    startingOffsetLeft: offsetLeft,
	                    startingOffsetTop: offsetTop,
	                    parentOffsetLeft: parentOffsetLeft,
	                    parentOffsetTop: parentOffsetTop,
	                    stellarRatio: ($this.data('stellar-background-ratio') === undefined ? 1 : $this.data('stellar-background-ratio'))
	                });
	            });
	        },
	        _reset: function() {
	            var particle,
	                startingPositionLeft,
	                startingPositionTop,
	                background,
	                i;

	            for (i = this.particles.length - 1; i >= 0; i--) {
	                particle = this.particles[i];
	                startingPositionLeft = particle.$element.data('stellar-startingLeft');
	                startingPositionTop = particle.$element.data('stellar-startingTop');

	                this._setPosition(particle.$element, startingPositionLeft, startingPositionLeft, startingPositionTop, startingPositionTop);

	                this.options.showElement(particle.$element);

	                particle.$element.data('stellar-startingLeft', null).data('stellar-elementIsActive', null).data('stellar-backgroundIsActive', null);
	            }

	            for (i = this.backgrounds.length - 1; i >= 0; i--) {
	                background = this.backgrounds[i];

	                background.$element.data('stellar-backgroundStartingLeft', null).data('stellar-backgroundStartingTop', null);

	                setBackgroundPosition(background.$element, background.startingValueLeft, background.startingValueTop);
	            }
	        },
	        destroy: function() {
	            this._reset();

	            this.$scrollElement.unbind('resize.' + this.name).unbind('scroll.' + this.name);
	            this._animationLoop = $.noop;

	            $(window).unbind('load.' + this.name).unbind('resize.' + this.name);
	        },
	        _setOffsets: function() {
	            var self = this,
	                $window = $(window);

	            $window.unbind('resize.horizontal-' + this.name).unbind('resize.vertical-' + this.name);

	            if (typeof this.options.horizontalOffset === 'function') {
	                this.horizontalOffset = this.options.horizontalOffset();
	                $window.bind('resize.horizontal-' + this.name, function() {
	                    self.horizontalOffset = self.options.horizontalOffset();
	                });
	            } else {
	                this.horizontalOffset = this.options.horizontalOffset;
	            }

	            if (typeof this.options.verticalOffset === 'function') {
	                this.verticalOffset = this.options.verticalOffset();
	                $window.bind('resize.vertical-' + this.name, function() {
	                    self.verticalOffset = self.options.verticalOffset();
	                });
	            } else {
	                this.verticalOffset = this.options.verticalOffset;
	            }
	        },
	        _repositionElements: function() {
	            var scrollLeft = this._getScrollLeft(),
	                scrollTop = this._getScrollTop(),
	                horizontalOffset,
	                verticalOffset,
	                particle,
	                fixedRatioOffset,
	                background,
	                bgLeft,
	                bgTop,
	                isVisibleVertical = true,
	                isVisibleHorizontal = true,
	                newPositionLeft,
	                newPositionTop,
	                newOffsetLeft,
	                newOffsetTop,
	                i;

	            // First check that the scroll position or container size has changed
	            if (this.currentScrollLeft === scrollLeft && this.currentScrollTop === scrollTop && this.currentWidth === this.viewportWidth && this.currentHeight === this.viewportHeight) {
	                return;
	            } else {
	                this.currentScrollLeft = scrollLeft;
	                this.currentScrollTop = scrollTop;
	                this.currentWidth = this.viewportWidth;
	                this.currentHeight = this.viewportHeight;
	            }

	            // Reposition elements
	            for (i = this.particles.length - 1; i >= 0; i--) {
	                particle = this.particles[i];

	                fixedRatioOffset = (particle.isFixed ? 1 : 0);

	                // Calculate position, then calculate what the particle's new offset will be (for visibility check)
	                if (this.options.horizontalScrolling) {
	                    newPositionLeft = (scrollLeft + particle.horizontalOffset + this.viewportOffsetLeft + particle.startingPositionLeft - particle.startingOffsetLeft + particle.parentOffsetLeft) * -(particle.stellarRatio + fixedRatioOffset - 1) + particle.startingPositionLeft;
	                    newOffsetLeft = newPositionLeft - particle.startingPositionLeft + particle.startingOffsetLeft;
	                } else {
	                    newPositionLeft = particle.startingPositionLeft;
	                    newOffsetLeft = particle.startingOffsetLeft;
	                }

	                if (this.options.verticalScrolling) {
	                    newPositionTop = (scrollTop + particle.verticalOffset + this.viewportOffsetTop + particle.startingPositionTop - particle.startingOffsetTop + particle.parentOffsetTop) * -(particle.stellarRatio + fixedRatioOffset - 1) + particle.startingPositionTop;
	                    newOffsetTop = newPositionTop - particle.startingPositionTop + particle.startingOffsetTop;
	                } else {
	                    newPositionTop = particle.startingPositionTop;
	                    newOffsetTop = particle.startingOffsetTop;
	                }

	                // Check visibility
	                if (this.options.hideDistantElements) {
	                    isVisibleHorizontal = !this.options.horizontalScrolling || newOffsetLeft + particle.width > (particle.isFixed ? 0 : scrollLeft) && newOffsetLeft < (particle.isFixed ? 0 : scrollLeft) + this.viewportWidth + this.viewportOffsetLeft;
	                    isVisibleVertical = !this.options.verticalScrolling || newOffsetTop + particle.height > (particle.isFixed ? 0 : scrollTop) && newOffsetTop < (particle.isFixed ? 0 : scrollTop) + this.viewportHeight + this.viewportOffsetTop;
	                }

	                if (isVisibleHorizontal && isVisibleVertical) {
	                    if (particle.isHidden) {
	                        this.options.showElement(particle.$element);
	                        particle.isHidden = false;
	                    }

	                    this._setPosition(particle.$element, newPositionLeft, particle.startingPositionLeft, newPositionTop, particle.startingPositionTop);
	                } else {
	                    if (!particle.isHidden) {
	                        this.options.hideElement(particle.$element);
	                        particle.isHidden = true;
	                    }
	                }
	            }

	            // Reposition backgrounds
	            for (i = this.backgrounds.length - 1; i >= 0; i--) {
	                background = this.backgrounds[i];

	                fixedRatioOffset = (background.isFixed ? 0 : 1);
	                bgLeft = (this.options.horizontalScrolling ? (scrollLeft + background.horizontalOffset - this.viewportOffsetLeft - background.startingOffsetLeft + background.parentOffsetLeft - background.startingBackgroundPositionLeft) * (fixedRatioOffset - background.stellarRatio) + 'px' : background.startingValueLeft);
	                bgTop = (this.options.verticalScrolling ? (scrollTop + background.verticalOffset - this.viewportOffsetTop - background.startingOffsetTop + background.parentOffsetTop - background.startingBackgroundPositionTop) * (fixedRatioOffset - background.stellarRatio) + 'px' : background.startingValueTop);

	                setBackgroundPosition(background.$element, bgLeft, bgTop);
	            }
	        },
	        _handleScrollEvent: function() {
	            var self = this,
	                ticking = false;

	            var update = function() {
	                self._repositionElements();
	                ticking = false;
	            };

	            var requestTick = function() {
	                if (!ticking) {
	                    requestAnimFrame(update);
	                    ticking = true;
	                }
	            };

	            this.$scrollElement.bind('scroll.' + this.name, requestTick);
	            requestTick();
	        },
	        _startAnimationLoop: function() {
	            var self = this;

	            this._animationLoop = function() {
	                requestAnimFrame(self._animationLoop);
	                self._repositionElements();
	            };
	            this._animationLoop();
	        }
	    };

	    $.fn[pluginName] = function (options) {
	        var args = arguments;
	        if (options === undefined || typeof options === 'object') {
	            return this.each(function () {
	                if (!$.data(this, 'plugin_' + pluginName)) {
	                    $.data(this, 'plugin_' + pluginName, new Plugin(this, options));
	                }
	            });
	        } else if (typeof options === 'string' && options[0] !== '_' && options !== 'init') {
	            return this.each(function () {
	                var instance = $.data(this, 'plugin_' + pluginName);
	                if (instance instanceof Plugin && typeof instance[options] === 'function') {
	                    instance[options].apply(instance, Array.prototype.slice.call(args, 1));
	                }
	                if (options === 'destroy') {
	                    $.data(this, 'plugin_' + pluginName, null);
	                }
	            });
	        }
	    };

	    $[pluginName] = function(options) {
	        var $window = $(window);
	        return $window.stellar.apply($window, Array.prototype.slice.call(arguments, 0));
	    };

	    // Expose the scroll and position property function hashes so they can be extended
	    $[pluginName].scrollProperty = scrollProperty;
	    $[pluginName].positionProperty = positionProperty;

	    // Expose the plugin class so it can be modified
	    window.Stellar = Plugin;
	}(jQuery, this, document));

/***/ },
/* 6 */
/***/ function(module, exports) {

	var SC=SC||{};SC.Widget=function(n){function t(r){if(e[r])return e[r].exports;var o=e[r]={exports:{},id:r,loaded:!1};return n[r].call(o.exports,o,o.exports,t),o.loaded=!0,o.exports}var e={};return t.m=n,t.c=e,t.p="",t(0)}([function(n,t,e){function r(n){return!!(""===n||n&&n.charCodeAt&&n.substr)}function o(n){return!!(n&&n.constructor&&n.call&&n.apply)}function i(n){return!(!n||1!==n.nodeType||"IFRAME"!==n.nodeName.toUpperCase())}function a(n){var t,e=!1;for(t in b)if(b.hasOwnProperty(t)&&b[t]===n){e=!0;break}return e}function s(n){var t,e,r;for(t=0,e=I.length;t<e&&(r=n(I[t]),r!==!1);t++);}function u(n){var t,e,r,o="";for("//"===n.substr(0,2)&&(n=window.location.protocol+n),r=n.split("/"),t=0,e=r.length;t<e&&t<3;t++)o+=r[t],t<2&&(o+="/");return o}function c(n){return n.contentWindow?n.contentWindow:n.contentDocument&&"parentWindow"in n.contentDocument?n.contentDocument.parentWindow:null}function l(n){var t,e=[];for(t in n)n.hasOwnProperty(t)&&e.push(n[t]);return e}function d(n,t,e){e.callbacks[n]=e.callbacks[n]||[],e.callbacks[n].push(t)}function E(n,t){var e,r=!0;return t.callbacks[n]=[],s(function(t){if(e=t.callbacks[n]||[],e.length)return r=!1,!1}),r}function f(n,t,e){var r,o,i=c(e);return!!i.postMessage&&(r=e.getAttribute("src").split("?")[0],o=JSON.stringify({method:n,value:t}),"//"===r.substr(0,2)&&(r=window.location.protocol+r),r=r.replace(/http:\/\/(w|wt).soundcloud.com/,"https://$1.soundcloud.com"),void i.postMessage(o,r))}function p(n){var t;return s(function(e){if(e.instance===n)return t=e,!1}),t}function h(n){var t;return s(function(e){if(c(e.element)===n)return t=e,!1}),t}function v(n,t){return function(e){var r=o(e),i=p(this),a=!r&&t?e:null,s=r&&!t?e:null;return s&&d(n,s,i),f(n,a,i.element),this}}function S(n,t,e){var r,o,i;for(r=0,o=t.length;r<o;r++)i=t[r],n[i]=v(i,e)}function R(n,t,e){return n+"?url="+t+"&"+g(e)}function g(n){var t,e,r=[];for(t in n)n.hasOwnProperty(t)&&(e=n[t],r.push(t+"="+("start_track"===t?parseInt(e,10):e?"true":"false")));return r.join("&")}function m(n,t,e){var r,o,i=n.callbacks[t]||[];for(r=0,o=i.length;r<o;r++)i[r].apply(n.instance,e);(a(t)||t===L.READY)&&(n.callbacks[t]=[])}function w(n){var t,e,r,o,i;try{e=JSON.parse(n.data)}catch(a){return!1}return t=h(n.source),r=e.method,o=e.value,(!t||A(n.origin)===A(t.domain))&&(t?(r===L.READY&&(t.isReady=!0,m(t,C),E(C,t)),r!==L.PLAY||t.playEventFired||(t.playEventFired=!0),r!==L.PLAY_PROGRESS||t.playEventFired||(t.playEventFired=!0,m(t,L.PLAY,[o])),i=[],void 0!==o&&i.push(o),void m(t,r,i)):(r===L.READY&&T.push(n.source),!1))}function A(n){return n.replace(Y,"")}var _,y,O,D=e(1),b=e(2),P=e(3),L=D.api,N=D.bridge,T=[],I=[],C="__LATE_BINDING__",k="http://wt.soundcloud.dev:9200/",Y=/^http(?:s?)/;window.addEventListener?window.addEventListener("message",w,!1):window.attachEvent("onmessage",w),n.exports=O=function(n,t,e){if(r(n)&&(n=document.getElementById(n)),!i(n))throw new Error("SC.Widget function should be given either iframe element or a string specifying id attribute of iframe element.");t&&(e=e||{},n.src=R(k,t,e));var o,a,s=h(c(n));return s&&s.instance?s.instance:(o=T.indexOf(c(n))>-1,a=new _(n),I.push(new y(a,n,o)),a)},O.Events=L,window.SC=window.SC||{},window.SC.Widget=O,y=function(n,t,e){this.instance=n,this.element=t,this.domain=u(t.getAttribute("src")),this.isReady=!!e,this.callbacks={}},_=function(){},_.prototype={constructor:_,load:function(n,t){if(n){t=t||{};var e=this,r=p(this),o=r.element,i=o.src,a=i.substr(0,i.indexOf("?"));r.isReady=!1,r.playEventFired=!1,o.onload=function(){e.bind(L.READY,function(){var n,e=r.callbacks;for(n in e)e.hasOwnProperty(n)&&n!==L.READY&&f(N.ADD_LISTENER,n,r.element);t.callback&&t.callback()})},o.src=R(a,n,t)}},bind:function(n,t){var e=this,r=p(this);return r&&r.element&&(n===L.READY&&r.isReady?setTimeout(t,1):r.isReady?(d(n,t,r),f(N.ADD_LISTENER,n,r.element)):d(C,function(){e.bind(n,t)},r)),this},unbind:function(n){var t,e=p(this);e&&e.element&&(t=E(n,e),n!==L.READY&&t&&f(N.REMOVE_LISTENER,n,e.element))}},S(_.prototype,l(b)),S(_.prototype,l(P),!0)},function(n,t){t.api={LOAD_PROGRESS:"loadProgress",PLAY_PROGRESS:"playProgress",PLAY:"play",PAUSE:"pause",FINISH:"finish",SEEK:"seek",READY:"ready",OPEN_SHARE_PANEL:"sharePanelOpened",CLICK_DOWNLOAD:"downloadClicked",CLICK_BUY:"buyClicked",ERROR:"error"},t.bridge={REMOVE_LISTENER:"removeEventListener",ADD_LISTENER:"addEventListener"}},function(n,t){n.exports={GET_VOLUME:"getVolume",GET_DURATION:"getDuration",GET_POSITION:"getPosition",GET_SOUNDS:"getSounds",GET_CURRENT_SOUND:"getCurrentSound",GET_CURRENT_SOUND_INDEX:"getCurrentSoundIndex",IS_PAUSED:"isPaused"}},function(n,t){n.exports={PLAY:"play",PAUSE:"pause",TOGGLE:"toggle",SEEK_TO:"seekTo",SET_VOLUME:"setVolume",NEXT:"next",PREV:"prev",SKIP:"skip"}}]);

/***/ },
/* 7 */
/***/ function(module, exports) {

	
	// if($.cookie("vmusic")) {
	//     $("link#link").attr("href",$.cookie("vmusic"));
	// }
	// $(document).ready(function() {
	//     $(".style-switcher a").click(function() {
	//         $("link#link").attr("href",$(this).attr('id'));
	//         $.cookie("vmusic",$(this).attr('id'), { path: '/'});
	//         return false;
	//     });
	//     // show-hide color pallete
	//     $('#toggle').click(function(e){
	//         e.preventDefault();
	//         var div = $('#style-switcher-container');
	//         console.log(div.css('left'));
	//         if (div.css('left') === '-130px') {
	//             $('#style-switcher-container').animate({
	//                 left: '0px'
	//             });
	//         } else {
	//             $('#style-switcher-container').animate({
	//                 left: '-130px'
	//             });
	//         }
	//     })
	// });


/***/ },
/* 8 */
/***/ function(module, exports) {

	$(window).on("load", function() {
	    "use strict";

	    // Page Load Animation
	    $("#preloaderV").delay(300).fadeOut("slow");
	});// END LOAD

	jQuery(document).ready(function($) {
	    "use strict";

	    // ScrollTo annimation
	    $('.scrollTo').on('click',function (e) {
	        e.preventDefault();
	        var target = this.hash,
	            $target = $(target);
	        $('body, html').stop().animate({
	                'scrollTop': $(target).offset().top-0
	            }, 1000, 'swing',
	            function() {
	                window.location.hash = target;
	            });
	    }); // End Click

	    // Scroll Top Animation
	    $('#scrollTop').on('click',function (e) {
	        $('html, body').animate({scrollTop : 0},800);
	        return false;
	    }); // End Click

	    // Form Validation
	    $('#contact-form').validate({
	        rules: {
	            email: {
	                required: true,
	                email: true
	            }
	        }, //end rules
	        messages: {
	            email: {
	                required: "Please type a e-mail address.",
	                email: "This is not a valid email address."
	            }
	        }
	    }); // end validate


	    // Masonry
	    var $masonryC = $('#masonry');
	    $masonryC.imagesLoaded( function(){
	        $masonryC.masonry({
	            columnWidth: '.grid-sizer',
	            itemSelector : '.item'
	        });
	    });

	    // Gallery LightBox
	    $('.popup-link').magnificPopup({
	        type: 'image',
	        gallery:{enabled:true}
	        // other options
	    });

	    // Shop Items Count
	    // $(".numbers-row").append('<div class="inc button">+</div><div class="dec button">-</div>');
	    // $(".button").on("click", function() {
	    //     var $button = $(this);
	    //     var oldValue = $button.parent().find("input").val();
	    //     if ($button.text() == "+") {
	    //         var newVal = parseFloat(oldValue) + 1;
	    //     } else {
	    //         // Don't allow decrementing below zero
	    //         if (oldValue > 0) {
	    //             var newVal = parseFloat(oldValue) - 1;
	    //         } else {
	    //             newVal = 0;
	    //         }
	    //     }
	    //     $button.parent().find("input").val(newVal);
	    // }); // End Click

	    // Open Close Social Media on scroll
	    $(window).on("scroll", function () {
	        if ($(this).scrollTop() > 100) {
	            $("#social-sidebar").addClass("scrolled");
	        }
	        else {
	            $("#social-sidebar").removeClass("scrolled");
	        }
	    });

	    // Stellar.js Parallax
	    $(function(){
	        $(window).stellar({
	            horizontalScrolling: false,
	            responsive: true,
	            parallaxBackgrounds: true
	        });
	    });

	    //Soundcloud widget
	    (function(){
	        var widgetIframe = document.getElementById('sc-widget'),
	            widget       = SC.Widget(widgetIframe);

	        widget.bind(SC.Widget.Events.READY, function() {
	            widget.bind(SC.Widget.Events.PLAY, function() {
	                // get information about currently playing sound
	                widget.getCurrentSound(function(currentSound) {
	                    //console.log('sound ' + currentSound.get('') + 'began to play');
	                });
	            });
	            // get current level of volume
	            widget.getVolume(function(volume) {
	                //console.log('current volume value is ' + volume);
	            });
	            // set new volume level
	            widget.setVolume(50);
	            // get the value of the current position
	        });

	    }());


	});// END READY




/***/ },
/* 9 */
/***/ function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ }
/******/ ]);